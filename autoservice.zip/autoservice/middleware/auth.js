module.exports = {
  ensureAuthenticated: function(req, res, next) {
    if (req.isAuthenticated()) {
      return next();
    }
    req.flash('error_msg', 'Пожалуйста, войдите в систему');
    res.redirect('/auth/login');
  },

  checkRole: function(roles) {
    return function(req, res, next) {
      if (req.isAuthenticated() && roles.includes(req.user.role)) {
        return next();
      }
      req.flash('error_msg', 'Недостаточно прав');
      res.redirect('/dashboard');
    }
  },

  forwardAuthenticated: function(req, res, next) {
    if (!req.isAuthenticated()) {
      return next();
    }
    res.redirect('/dashboard');  
  }
};