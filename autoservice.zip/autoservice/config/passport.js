const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;
const bcrypt = require('bcrypt');
const pool = require('./db');

passport.use(
  new LocalStrategy(
    {
      usernameField: 'email',
      passwordField: 'password',
      passReqToCallback: true
    },
    async (req, email, password, done) => {
      try {
        const result = await pool.query(
          'SELECT * FROM employees WHERE email = $1 AND is_active = TRUE', 
          [email]
        );
        
        if (result.rows.length === 0) {
          return done(null, false, { message: 'Пользователь не найден' });
        }

        const user = result.rows[0];
        
        if (!user.password) {
          return done(null, false, { message: 'Неверные учетные данные' });
        }

        const isValidPassword = await bcrypt.compare(password, user.password);
        
        if (!isValidPassword) {
          return done(null, false, { message: 'Неверный пароль' });
        }

        return done(null, user);
      } catch (error) {
        return done(error);
      }
    }
  )
);

passport.serializeUser((user, done) => {
  done(null, user.employeeid);
});

passport.deserializeUser(async (id, done) => {
  try {
    const result = await pool.query(
      'SELECT employeeid, fullname, email, role, phone FROM employees WHERE employeeid = $1', 
      [id]
    );
    done(null, result.rows[0]);
  } catch (error) {
    done(error);
  }
});

module.exports = passport;