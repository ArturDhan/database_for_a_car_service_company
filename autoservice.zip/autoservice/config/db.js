const { Pool } = require('pg');

const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'autoservice',
  password: '22081921',
  port: 5432,
});

module.exports = pool;