require('dotenv').config();
const express = require('express');
const session = require('express-session');
const passport = require('passport');
const flash = require('express-flash');
const path = require('path');
const morgan = require('morgan');
const expressLayouts = require('express-ejs-layouts');
const helmet = require('helmet');

const app = express();

// База данных
require('./config/db');
require('./config/passport');

// Middleware
app.use(helmet());
app.use(expressLayouts);
app.set('view engine', 'ejs');
app.set('layout', 'layouts/main');
app.set('views', path.join(__dirname, 'views'));

app.use(express.static(path.join(__dirname, 'public')));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(morgan('dev'));

// Сессии
app.use(session({
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: { 
    secure: process.env.NODE_ENV === 'production',
    maxAge: 24 * 60 * 60 * 1000 // 1 день
  }
}));

// Passport
app.use(passport.initialize());
app.use(passport.session());

// Flash
app.use(flash());

// Локальные переменные
app.use((req, res, next) => {
  res.locals.user = req.user || null;
  res.locals.success_msg = req.flash('success_msg');
  res.locals.error_msg = req.flash('error_msg');
  next();
});

// Главная страница
app.get('/', (req, res) => {
  res.render('index', { title: 'Главная страница' }); 
});

// Панель управления
app.get('/dashboard', (req, res) => {
  res.render('dashboard', { title: 'Панель управления' });
});

// Роуты
app.use('/', require('./routes/index'));
app.use('/auth', require('./routes/auth'));
app.use('/admin', require('./middleware/auth').checkRole(['admin']), require('./routes/admin'));
app.use('/mechanic', require('./middleware/auth').checkRole(['mechanic', 'senior_mechanic']), require('./routes/mechanic'));
app.use('/reception', require('./middleware/auth').checkRole(['receptionist', 'admin']), require('./routes/reception'));
app.use('/clients', require('./middleware/auth').ensureAuthenticated, require('./routes/clients'));
app.use('/cars', require('./middleware/auth').ensureAuthenticated, require('./routes/cars'));
app.use('/services', require('./middleware/auth').ensureAuthenticated, require('./routes/services'));
app.use('/employees', require('./middleware/auth').checkRole(['admin']), require('./routes/employees')); // Добавление маршрута для сотрудников
app.use('/appointments', require('./middleware/auth').ensureAuthenticated, require('./routes/appointments')); // Добавление маршрута для записей

// Ошибка 404
app.use((req, res) => {
  res.status(404).render('404', { title: 'Страница не найдена' });
});

// Обработка ошибок
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).render('500', { title: 'Ошибка сервера' });
});

// Запуск сервера
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Сервер запущен на http://localhost:${PORT}`);
});