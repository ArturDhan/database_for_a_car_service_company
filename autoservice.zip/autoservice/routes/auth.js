const express = require('express');
const router = express.Router();
const passport = require('passport');

// Вход
router.get('/login', (req, res) => {
  res.render('auth/login', {
    title: 'Вход в систему',
    error_msg: req.flash('error_msg') // Передаем сообщение об ошибке в шаблон
  });
});

// Обработка входа
router.post('/login', (req, res, next) => {
  passport.authenticate('local', (err, user, info) => {
    if (err) return next(err);
    if (!user) {
      req.flash('error_msg', info.message); // Сохраняем сообщение об ошибке в flash
      return res.redirect('/auth/login');
    }
    req.logIn(user, (err) => {
      if (err) return next(err);
      req.flash('success_msg', 'Вы успешно вошли в систему'); // Сообщение об успехе
      return res.redirect('/dashboard');
    });
  })(req, res, next);
});

// Выход
router.get('/logout', (req, res) => {
  req.logout((err) => {
    if (err) {
      console.error(err);
      req.flash('error_msg', 'Ошибка при выходе');
      return res.redirect('/dashboard'); // Перенаправляем на панель управления в случае ошибки
    }
    req.flash('success_msg', 'Вы вышли из системы');
    res.redirect('/');
  });
});

module.exports = router;