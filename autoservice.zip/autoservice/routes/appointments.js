const express = require('express');
const router = express.Router();
const { check, validationResult } = require('express-validator');
const pool = require('../config/db');
const { ensureAuthenticated } = require('../middleware/auth');

// Список записей
router.get('/', ensureAuthenticated, async (req, res) => {
  try {
    const appointments = await pool.query(`
      SELECT a.appointmentid, a.datetime, a.status, c.brand, c.model, cl.fullname as client_name
      FROM appointments a
      JOIN cars c ON a.carid = c.carid
      JOIN clients cl ON c.clientid = cl.clientid
      ORDER BY a.datetime DESC
    `);
    res.render('appointments/list', {
      title: 'Записи',
      appointments: appointments.rows
    });
  } catch (err) {
    console.error(err);
    req.flash('error_msg', 'Ошибка загрузки записей');
    res.redirect('/');
  }
});

// Форма добавления записи
router.get('/add', ensureAuthenticated, async (req, res) => {
  try {
    const clients = await pool.query('SELECT * FROM clients ORDER BY fullname');
    const cars = await pool.query('SELECT * FROM cars ORDER BY brand');
    res.render('appointments/add', {
      title: 'Добавить запись',
      clients: clients.rows,
      cars: cars.rows
    });
  } catch (err) {
    console.error(err);
    req.flash('error_msg', 'Ошибка загрузки данных');
    res.redirect('/appointments');
  }
});

// Обработка добавления записи
router.post('/add', ensureAuthenticated, [
  check('datetime').notEmpty().withMessage('Дата и время обязательны'),
  check('carid').notEmpty().withMessage('Выберите автомобиль'),
  check('clientid').notEmpty().withMessage('Выберите клиента'),
  check('status').isIn(['pending', 'in_progress', 'completed', 'cancelled']).withMessage('Неверный статус')
], async (req, res) => {
  const errors = validationResult(req);
  
  if (!errors.isEmpty()) {
    return res.render('appointments/add', {
      title: 'Добавить запись',
      errors: errors.array(),
      appointment: req.body
    });
  }

  const { datetime, carid, clientid, status } = req.body;

  try {
    await pool.query(
      `INSERT INTO appointments (datetime, carid, clientid, status)
       VALUES ($1, $2, $3, $4)`,
      [datetime, carid, clientid, status]
    );
    
    req.flash('success_msg', 'Запись успешно добавлена');
    res.redirect('/appointments');
  } catch (err) {
    console.error(err);
    req.flash('error_msg', 'Ошибка при добавлении записи');
    res.redirect('/appointments/add');
  }
});

// Форма редактирования записи
router.get('/edit/:id', ensureAuthenticated, async (req, res) => {
  try {
    const appointment = await pool.query('SELECT * FROM appointments WHERE appointmentid = $1', [req.params.id]);
    const clients = await pool.query('SELECT * FROM clients ORDER BY fullname');
    const cars = await pool.query('SELECT * FROM cars ORDER BY brand');

    if (appointment.rows.length === 0) {
      req.flash('error_msg', 'Запись не найдена');
      return res.redirect('/appointments');
    }

    res.render('appointments/edit', {
      title: 'Редактировать запись',
      appointment: appointment.rows[0],
      clients: clients.rows,
      cars: cars.rows
    });
  } catch (err) {
    console.error(err);
    req.flash('error_msg', 'Ошибка загрузки данных');
    res.redirect('/appointments');
  }
});

// Обработка редактирования записи
router.post('/edit/:id', ensureAuthenticated, [
  check('datetime').notEmpty().withMessage('Дата и время обязательны'),
  check('carid').notEmpty().withMessage('Выберите автомобиль'),
  check('clientid').notEmpty().withMessage('Выберите клиента'),
  check('status').isIn(['pending', 'in_progress', 'completed', 'cancelled']).withMessage('Неверный статус')
], async (req, res) => {
  const errors = validationResult(req);
  
  if (!errors.isEmpty()) {
    return res.render('appointments/edit', {
      title: 'Редактировать запись',
      errors: errors.array(),
      appointment: req.body
    });
  }

  const { datetime, carid, clientid, status } = req.body;

  try {
    await pool.query(
      `UPDATE appointments 
       SET datetime = $1, carid = $2, clientid = $3, status = $4 
       WHERE appointmentid = $5`,
      [datetime, carid, clientid, status, req.params.id]
    );
    
    req.flash('success_msg', 'Запись успешно обновлена');
    res.redirect('/appointments');
  } catch (err) {
    console.error(err);
    req.flash('error_msg', 'Ошибка при обновлении записи');
    res.redirect(`/appointments/edit/${req.params.id}`);
  }
});

// Удаление записи
router.post('/delete/:id', ensureAuthenticated, async (req, res) => {
  try {
    await pool.query('DELETE FROM appointments WHERE appointmentid = $1', [req.params.id]);
    req.flash('success_msg', 'Запись успешно удалена');
  } catch (err) {
    console.error(err);
    req.flash('error_msg', 'Ошибка при удалении записи');
  }
  res.redirect('/appointments');
});

module.exports = router;