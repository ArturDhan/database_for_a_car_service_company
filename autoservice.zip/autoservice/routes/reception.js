const express = require('express');
const router = express.Router();

// Главная страница приема
router.get('/', (req, res) => {
    try {
        res.send('Страница приема');
    } catch (err) {
        console.error(err);
        res.status(500).send('Ошибка сервера');
    }
});

module.exports = router;