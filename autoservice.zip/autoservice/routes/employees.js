const express = require('express');
const router = express.Router();
const { check, validationResult } = require('express-validator');
const bcrypt = require('bcrypt');
const pool = require('../config/db');

// Список сотрудников
router.get('/', async (req, res) => {
  try {
    const employees = await pool.query(
      'SELECT employeeid, fullname, email, phone, role, is_active FROM employees ORDER BY fullname'
    );
    res.render('admin/employees', {
      title: 'Сотрудники',
      employees: employees.rows,
    });
  } catch (err) {
    console.error(err);
    req.flash('error_msg', 'Ошибка загрузки данных');
    res.redirect('/');
  }
});

// Форма добавления сотрудника
router.get('/add', (req, res) => {
  res.render('admin/add-employee', {
    title: 'Добавить сотрудника',
    roles: ['admin', 'mechanic', 'senior_mechanic', 'receptionist', 'accountant'],
    employee: {} // Передаем пустой объект вместо null
  });
});

// Обработка добавления сотрудника
router.post('/add', [
  check('fullname').notEmpty().withMessage('Имя обязательно'),
  check('email').isEmail().withMessage('Неверный формат email'),
  check('phone').isMobilePhone().withMessage('Неверный формат телефона'),
  check('role').isIn(['admin', 'mechanic', 'senior_mechanic', 'receptionist', 'accountant']).withMessage('Неверная роль'),
  check('password').isLength({ min: 6 }).withMessage('Пароль должен быть не менее 6 символов'),
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.render('admin/add-employee', {
      title: 'Добавить сотрудника',
      roles: ['admin', 'mechanic', 'senior_mechanic', 'receptionist', 'accountant'],
      errors: errors.array(),
      employee: req.body // Передаем данные из формы
    });
  }

  const { fullname, email, phone, role, password } = req.body;

  try {
    // Проверяем, существует ли уже сотрудник с таким email
    const existingEmployee = await pool.query(
      'SELECT * FROM employees WHERE email = $1',
      [email]
    );

    if (existingEmployee.rows.length > 0) {
      return res.render('admin/add-employee', {
        title: 'Добавить сотрудника',
        roles: ['admin', 'mechanic', 'senior_mechanic', 'receptionist', 'accountant'],
        errors: [{ msg: 'Сотрудник с таким email уже существует' }],
        employee: req.body
      });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    await pool.query(
      `INSERT INTO employees (fullname, email, phone, role, password, is_active)
       VALUES ($1, $2, $3, $4, $5, TRUE)`,
      [fullname, email, phone, role, hashedPassword]
    );
    req.flash('success_msg', 'Сотрудник успешно добавлен');
    res.redirect('/admin/employees');
  } catch (err) {
    console.error(err);
    req.flash('error_msg', 'Ошибка при добавлении сотрудника');
    res.redirect('/admin/employees/add');
  }
});

// Форма редактирования сотрудника
router.get('/edit/:id', async (req, res) => {
  try {
    const employee = await pool.query(
      'SELECT employeeid, fullname, email, phone, role FROM employees WHERE employeeid = $1',
      [req.params.id]
    );

    if (employee.rows.length === 0) {
      req.flash('error_msg', 'Сотрудник не найден');
      return res.redirect('/admin/employees');
    }
    
    res.render('admin/add-employee', {
      title: 'Редактировать сотрудника',
      employee: employee.rows[0],
      roles: ['admin', 'mechanic', 'senior_mechanic', 'receptionist', 'accountant'],
    });
  } catch (err) {
    console.error(err);
    req.flash('error_msg', 'Ошибка загрузки данных');
    res.redirect('/admin/employees');
  }
});

// Обработка редактирования сотрудника
router.post('/edit/:id', [
  check('fullname').notEmpty().withMessage('Имя обязательно'),
  check('email').isEmail().withMessage('Неверный формат email'),
  check('phone').isMobilePhone().withMessage('Неверный формат телефона'),
  check('role').isIn(['admin', 'mechanic', 'senior_mechanic', 'receptionist', 'accountant']).withMessage('Неверная роль'),
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.render('admin/add-employee', {
      title: 'Редактировать сотрудника',
      roles: ['admin', 'mechanic', 'senior_mechanic', 'receptionist', 'accountant'],
      errors: errors.array(),
      employee: { ...req.body, employeeid: req.params.id } // Добавляем ID к данным формы
    });
  }

  const { fullname, email, phone, role } = req.body;

  try {
    // Проверяем, не используется ли email другим сотрудником
    const emailCheck = await pool.query(
      'SELECT employeeid FROM employees WHERE email = $1 AND employeeid != $2',
      [email, req.params.id]
    );

    if (emailCheck.rows.length > 0) {
      return res.render('admin/add-employee', {
        title: 'Редактировать сотрудника',
        roles: ['admin', 'mechanic', 'senior_mechanic', 'receptionist', 'accountant'],
        errors: [{ msg: 'Этот email уже используется другим сотрудником' }],
        employee: { ...req.body, employeeid: req.params.id }
      });
    }

    await pool.query(
      `UPDATE employees
       SET fullname = $1, email = $2, phone = $3, role = $4
       WHERE employeeid = $5`,
      [fullname, email, phone, role, req.params.id]
    );
    req.flash('success_msg', 'Данные сотрудника обновлены');
    res.redirect('/admin/employees');
  } catch (err) {
    console.error(err);
    req.flash('error_msg', 'Ошибка при обновлении данных');
    res.redirect(`/admin/employees/edit/${req.params.id}`);
  }
});

// Удаление сотрудника
router.post('/delete/:id', async (req, res) => {
  try {
    await pool.query('DELETE FROM employees WHERE employeeid = $1', [req.params.id]);
    req.flash('success_msg', 'Сотрудник успешно удален');
  } catch (err) {
    console.error(err);
    req.flash('error_msg', 'Ошибка при удалении сотрудника');
  }
  res.redirect('/admin/employees');
});

module.exports = router;