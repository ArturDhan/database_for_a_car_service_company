const express = require('express');
const router = express.Router();

// Главная страница
router.get('/', (req, res) => {
    try {
        res.send('Главная страница');
    } catch (err) {
        console.error(err);
        res.status(500).send('Ошибка сервера');
    }
});

module.exports = router;