const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const { ensureAuthenticated } = require('../middleware/auth');

// Роут для отображения списка клиентов
router.get('/', ensureAuthenticated, async (req, res) => {
  try {
    // Получаем клиентов из базы данных
    const clients = await pool.query('SELECT * FROM clients ORDER BY clientid');
    
    // Передаем данные в шаблон
    res.render('clients/list', {
      title: 'Список клиентов',
      clients: clients.rows // Передаем клиентов в шаблон
    });
  } catch (err) {
    console.error(err);
    req.flash('error_msg', 'Ошибка загрузки клиентов');
    res.redirect('/');
  }
});

// Роут для отображения формы добавления клиента
router.get('/add', ensureAuthenticated, (req, res) => {
  res.render('clients/add', {
    title: 'Добавить клиента'
  });
});

// Роут для обработки добавления клиента
router.post('/add', ensureAuthenticated, async (req, res) => {
  try {
    const { fullname, phone, email, address } = req.body;
    await pool.query(
      'INSERT INTO clients (fullname, phone, email, address) VALUES ($1, $2, $3, $4)',
      [fullname, phone, email, address]
    );
    req.flash('success_msg', 'Клиент успешно добавлен');
    res.redirect('/clients');
  } catch (err) {
    console.error(err);
    req.flash('error_msg', 'Ошибка при добавлении клиента');
    res.redirect('/clients/add');
  }
});

// Роут для отображения формы редактирования клиента
router.get('/edit/:id', ensureAuthenticated, async (req, res) => {
  try {
    const client = await pool.query('SELECT * FROM clients WHERE clientid = $1', [req.params.id]);

    if (client.rows.length === 0) {
      req.flash('error_msg', 'Клиент не найден');
      return res.redirect('/clients');
    }
    
    res.render('clients/edit', {
      title: 'Редактировать клиента',
      client: client.rows[0]
    });
  } catch (err) {
    console.error(err);
    req.flash('error_msg', 'Клиент не найден');
    res.redirect('/clients');
  }
});

// Роут для обработки редактирования клиента
router.post('/edit/:id', ensureAuthenticated, async (req, res) => {
  try {
    const { fullname, phone, email, address } = req.body;
    await pool.query(
      'UPDATE clients SET fullname = $1, phone = $2, email = $3, address = $4 WHERE clientid = $5',
      [fullname, phone, email, address, req.params.id]
    );
    req.flash('success_msg', 'Данные клиента обновлены');
    res.redirect('/clients');
  } catch (err) {
    console.error(err);
    req.flash('error_msg', 'Ошибка при обновлении данных');
    res.redirect(`/clients/edit/${req.params.id}`);
  }
});

// Роут для удаления клиента
router.post('/delete/:id', ensureAuthenticated, async (req, res) => {
  try {
    await pool.query('DELETE FROM clients WHERE clientid = $1', [req.params.id]);
    req.flash('success_msg', 'Клиент успешно удален');
  } catch (err) {
    console.error(err);
    req.flash('error_msg', 'Ошибка при удалении клиента');
  }
  res.redirect('/clients');
});

module.exports = router;