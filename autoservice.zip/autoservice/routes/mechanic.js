const express = require('express');
const router = express.Router();
const { check, validationResult } = require('express-validator');
const pool = require('../config/db');
const { ensureAuthenticated, checkRole } = require('../middleware/auth');

// Список рабочих заданий для механика
router.get('/work-orders', 
    ensureAuthenticated, 
    checkRole(['mechanic', 'senior_mechanic']), 
    async (req, res) => {
        try {
            const orders = await pool.query(`
                SELECT 
                    a.appointmentid,
                    a.datetime,
                    a.status,
                    c.brand,
                    c.model,
                    c.year,
                    cl.fullname as client_name,
                    cl.phone as client_phone,
                    s.servicename,
                    s.price
                FROM appointments a
                JOIN cars c ON a.carid = c.carid
                JOIN clients cl ON c.clientid = cl.clientid
                JOIN services s ON a.serviceid = s.serviceid
                WHERE a.employeeid = $1
                ORDER BY a.datetime DESC
            `, [req.user.employeeid]);

            res.render('mechanic/orders', {
                title: 'Мои рабочие задания',
                orders: orders.rows,
                statusColors: {
                    'pending': 'warning',
                    'in_progress': 'info',
                    'completed': 'success',
                    'cancelled': 'danger'
                }
            });
        } catch (err) {
            console.error(err);
            req.flash('error_msg', 'Ошибка загрузки данных');
            res.redirect('/dashboard');
        }
    }
);

// Обновление статуса работы
router.post('/work-orders/:id/update-status', 
    ensureAuthenticated, 
    checkRole(['mechanic', 'senior_mechanic']),
    [
        check('status').isIn(['pending', 'in_progress', 'completed', 'cancelled']).withMessage('Неверный статус')
    ],
    async (req, res) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            req.flash('error_msg', errors.array().map(err => err.msg).join(', '));
            return res.redirect('/mechanic/work-orders');
        }

        try {
            await pool.query(
                'UPDATE appointments SET status = $1 WHERE appointmentid = $2 AND employeeid = $3',
                [req.body.status, req.params.id, req.user.employeeid]
            );
            req.flash('success_msg', 'Статус обновлен');
        } catch (err) {
            console.error(err);
            req.flash('error_msg', 'Ошибка обновления статуса');
        }
        
        res.redirect('/mechanic/work-orders');
    }
);

module.exports = router;