const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const { ensureAuthenticated } = require('../middleware/auth');

// Список услуг
router.get('/', ensureAuthenticated, async (req, res) => {
  try {
    const services = await pool.query('SELECT * FROM services');
    res.render('services/list', {
      title: 'Услуги',
      services: services.rows // Передаем services.rows в шаблон
    });
  } catch (err) {
    console.error(err);
    req.flash('error_msg', 'Ошибка загрузки услуг');
    res.redirect('/'); // Перенаправляем на главную страницу в случае ошибки
  }
});

// Форма добавления услуги
router.get('/add', ensureAuthenticated, (req, res) => {
  res.render('services/add', { title: 'Добавить услугу' });
});

// Обработка добавления услуги
router.post('/add', ensureAuthenticated, async (req, res) => {
  const { servicename, description, price } = req.body;
  try {
    await pool.query(
      `INSERT INTO services (servicename, description, price) 
      VALUES ($1, $2, $3)`,
      [servicename, description, price]
    );
    req.flash('success_msg', 'Услуга успешно добавлена');
    res.redirect('/services');
  } catch (err) {
    console.error(err);
    req.flash('error_msg', 'Ошибка при добавлении услуги');
    res.redirect('/services/add');
  }
});

// Форма редактирования услуги
router.get('/edit/:id', ensureAuthenticated, async (req, res) => {
  try {
    const service = await pool.query('SELECT * FROM services WHERE serviceid = $1', [req.params.id]);

    if (service.rows.length === 0) {
      req.flash('error_msg', 'Услуга не найдена');
      return res.redirect('/services');
    }

    res.render('services/edit', {
      title: 'Редактировать услугу',
      service: service.rows[0] // Передаем первый элемент массива
    });
  } catch (err) {
    console.error(err);
    req.flash('error_msg', 'Ошибка загрузки услуги');
    res.redirect('/services');
  }
});

// Обработка редактирования услуги
router.post('/edit/:id', ensureAuthenticated, async (req, res) => {
  const { servicename, description, price } = req.body;
  try {
    await pool.query(
      `UPDATE services 
      SET servicename = $1, description = $2, price = $3 
      WHERE serviceid = $4`,
      [servicename, description, price, req.params.id]
    );
    req.flash('success_msg', 'Услуга успешно обновлена');
    res.redirect('/services');
  } catch (err) {
    console.error(err);
    req.flash('error_msg', 'Ошибка при обновлении услуги');
    res.redirect(`/services/edit/${req.params.id}`);
  }
});

// Удаление услуги
router.post('/delete/:id', ensureAuthenticated, async (req, res) => {
  try {
    await pool.query('DELETE FROM services WHERE serviceid = $1', [req.params.id]);
    req.flash('success_msg', 'Услуга успешно удалена');
  } catch (err) {
    console.error(err);
    req.flash('error_msg', 'Ошибка при удалении услуги');
  }
  res.redirect('/services');
});

module.exports = router;