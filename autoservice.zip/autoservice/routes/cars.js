const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const { ensureAuthenticated } = require('../middleware/auth');

// Список автомобилей
router.get('/', ensureAuthenticated, async (req, res) => {
  try {
    const cars = await pool.query(`
      SELECT c.*, cl.fullname as client_name 
      FROM cars c
      LEFT JOIN clients cl ON c.clientid = cl.clientid
      ORDER BY c.carid
    `);
    res.render('cars/list', {
      title: 'Автомобили',
      cars: cars.rows
    });
  } catch (err) {
    console.error(err);
    req.flash('error_msg', 'Ошибка загрузки автомобилей');
    res.redirect('/');
  }
});

// Форма добавления
router.get('/add', ensureAuthenticated, async (req, res) => {
  try {
    const clients = await pool.query('SELECT * FROM clients ORDER BY fullname');
    res.render('cars/add', {
      title: 'Добавить автомобиль',
      clients: clients.rows
    });
  } catch (err) {
    console.error(err);
    req.flash('error_msg', 'Ошибка загрузки клиентов');
    res.redirect('/cars');
  }
});

// Обработка добавления
router.post('/add', ensureAuthenticated, async (req, res) => {
  const { brand, model, year, vin, clientid } = req.body;
  try {
    await pool.query(
      `INSERT INTO cars (brand, model, year, vin, clientid)
       VALUES ($1, $2, $3, $4, $5)`,
      [brand, model, year, vin, clientid]
    );
    req.flash('success_msg', 'Автомобиль успешно добавлен');
    res.redirect('/cars');
  } catch (err) {
    console.error(err);
    req.flash('error_msg', 'Ошибка при добавлении автомобиля');
    res.redirect('/cars/add');
  }
});

// Форма редактирования
router.get('/edit/:id', ensureAuthenticated, async (req, res) => {
  try {
    const [car, clients] = await Promise.all([
      pool.query('SELECT * FROM cars WHERE carid = $1', [req.params.id]),
      pool.query('SELECT * FROM clients ORDER BY fullname')
    ]);

    if (car.rows.length === 0) {
      req.flash('error_msg', 'Автомобиль не найден');
      return res.redirect('/cars');
    }
    
    res.render('cars/edit', {
      title: 'Редактировать автомобиль',
      car: car.rows[0],
      clients: clients.rows
    });
  } catch (err) {
    console.error(err);
    req.flash('error_msg', 'Ошибка загрузки данных');
    res.redirect('/cars');
  }
});

// Обработка редактирования
router.post('/edit/:id', ensureAuthenticated, async (req, res) => {
  const { brand, model, year, vin, clientid } = req.body;
  try {
    await pool.query(
      `UPDATE cars SET
        brand = $1,
        model = $2,
        year = $3,
        vin = $4,
        clientid = $5
       WHERE carid = $6`,
      [brand, model, year, vin, clientid, req.params.id]
    );
    req.flash('success_msg', 'Автомобиль успешно обновлен');
    res.redirect('/cars');
  } catch (err) {
    console.error(err);
    req.flash('error_msg', 'Ошибка при обновлении автомобиля');
    res.redirect(`/cars/edit/${req.params.id}`);
  }
});

// Удаление
router.post('/delete/:id', ensureAuthenticated, async (req, res) => {
  try {
    await pool.query('DELETE FROM cars WHERE carid = $1', [req.params.id]);
    req.flash('success_msg', 'Автомобиль успешно удален');
  } catch (err) {
    console.error(err);
    req.flash('error_msg', 'Ошибка при удалении автомобиля');
  }
  res.redirect('/cars');
});

module.exports = router;