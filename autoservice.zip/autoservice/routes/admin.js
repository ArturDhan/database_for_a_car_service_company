const express = require('express');
const router = express.Router();
const { check, validationResult } = require('express-validator');
const bcrypt = require('bcrypt');
const pool = require('../config/db');

// Панель администратора
router.get('/', (req, res) => {
  res.render('admin/dashboard', {
    title: 'Панель администратора'
  });
});

// Список сотрудников
router.get('/employees', async (req, res) => {
  try {
    const employees = await pool.query(
      'SELECT employeeid, fullname, email, phone, role, is_active FROM employees ORDER BY fullname'
    );
    
    res.render('admin/employees', {
      title: 'Управление сотрудниками',
      employees: employees.rows,
      success_msg: req.flash('success_msg'),
      error_msg: req.flash('error_msg')
    });
  } catch (err) {
    console.error(err);
    req.flash('error_msg', 'Ошибка загрузки данных');
    res.redirect('/admin');
  }
});

// Добавление сотрудника
router.get('/employees/add', (req, res) => {
  res.render('admin/add-employee', {
    title: 'Добавить сотрудника',
    roles: ['admin', 'mechanic', 'senior_mechanic', 'receptionist', 'accountant'],
    employee: {}, // Добавлен пустой объект employee
    error_msg: req.flash('error_msg')
  });
});

router.post('/employees/add', [
  check('fullname').notEmpty().trim().withMessage('Имя обязательно'),
  check('email').isEmail().normalizeEmail().withMessage('Неверный формат email'),
  check('phone').isMobilePhone('ru-RU').withMessage('Неверный формат телефона'),
  check('role').isIn(['admin', 'mechanic', 'senior_mechanic', 'receptionist', 'accountant']).withMessage('Неверная роль'),
  check('password').isLength({ min: 6 }).withMessage('Пароль должен быть не менее 6 символов')
], async (req, res) => {
  const errors = validationResult(req);
  
  if (!errors.isEmpty()) {
    return res.render('admin/add-employee', {
      title: 'Добавить сотрудника',
      roles: ['admin', 'mechanic', 'senior_mechanic', 'receptionist', 'accountant'],
      errors: errors.array(),
      employee: req.body
    });
  }

  const { fullname, email, phone, role, password } = req.body;

  try {
    // Проверка на существующего сотрудника
    const existingEmployee = await pool.query(
      'SELECT * FROM employees WHERE email = $1',
      [email]
    );

    if (existingEmployee.rows.length > 0) {
      return res.render('admin/add-employee', {
        title: 'Добавить сотрудника',
        roles: ['admin', 'mechanic', 'senior_mechanic', 'receptionist', 'accountant'],
        errors: [{ msg: 'Сотрудник с таким email уже существует' }],
        employee: req.body
      });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    
    await pool.query(
      `INSERT INTO employees (fullname, email, phone, role, password, is_active)
       VALUES ($1, $2, $3, $4, $5, TRUE)`,
      [fullname, email, phone, role, hashedPassword]
    );
    
    req.flash('success_msg', 'Сотрудник успешно добавлен');
    res.redirect('/admin/employees');
  } catch (err) {
    console.error(err);
    req.flash('error_msg', 'Ошибка при добавлении сотрудника');
    res.redirect('/admin/employees/add');
  }
});

// Редактирование сотрудника
router.get('/employees/edit/:id', async (req, res) => {
  try {
    const employee = await pool.query(
      'SELECT employeeid, fullname, email, phone, role, is_active FROM employees WHERE employeeid = $1',
      [req.params.id]
    );

    if (employee.rows.length === 0) {
      req.flash('error_msg', 'Сотрудник не найден');
      return res.redirect('/admin/employees');
    }
    
    res.render('admin/edit-employee', {
      title: 'Редактировать сотрудника',
      employee: employee.rows[0],
      roles: ['admin', 'mechanic', 'senior_mechanic', 'receptionist', 'accountant'],
      error_msg: req.flash('error_msg')
    });
  } catch (err) {
    console.error(err);
    req.flash('error_msg', 'Ошибка загрузки данных');
    res.redirect('/admin/employees');
  }
});

router.post('/employees/edit/:id', [
  check('fullname').notEmpty().trim().withMessage('Имя обязательно'),
  check('email').isEmail().normalizeEmail().withMessage('Неверный формат email'),
  check('phone').isMobilePhone('ru-RU').withMessage('Неверный формат телефона'),
  check('role').isIn(['admin', 'mechanic', 'senior_mechanic', 'receptionist', 'accountant']).withMessage('Неверная роль')
], async (req, res) => {
  const errors = validationResult(req);
  
  if (!errors.isEmpty()) {
    return res.render('admin/edit-employee', {
      title: 'Редактировать сотрудника',
      roles: ['admin', 'mechanic', 'senior_mechanic', 'receptionist', 'accountant'],
      errors: errors.array(),
      employee: { ...req.body, employeeid: req.params.id }
    });
  }

  const { fullname, email, phone, role } = req.body;

  try {
    // Проверка email на уникальность
    const emailCheck = await pool.query(
      'SELECT employeeid FROM employees WHERE email = $1 AND employeeid != $2',
      [email, req.params.id]
    );

    if (emailCheck.rows.length > 0) {
      return res.render('admin/edit-employee', {
        title: 'Редактировать сотрудника',
        roles: ['admin', 'mechanic', 'senior_mechanic', 'receptionist', 'accountant'],
        errors: [{ msg: 'Этот email уже используется другим сотрудником' }],
        employee: { ...req.body, employeeid: req.params.id }
      });
    }

    await pool.query(
      `UPDATE employees 
       SET fullname = $1, email = $2, phone = $3, role = $4 
       WHERE employeeid = $5`,
      [fullname, email, phone, role, req.params.id]
    );
    
    req.flash('success_msg', 'Данные сотрудника обновлены');
    res.redirect('/admin/employees');
  } catch (err) {
    console.error(err);
    req.flash('error_msg', 'Ошибка при обновлении данных');
    res.redirect(`/admin/employees/edit/${req.params.id}`);
  }
});

// Активация/деактивация сотрудника
router.post('/employees/toggle/:id', async (req, res) => {
  try {
    const current = await pool.query(
      'SELECT is_active FROM employees WHERE employeeid = $1',
      [req.params.id]
    );

    if (current.rows.length === 0) {
      req.flash('error_msg', 'Сотрудник не найден');
      return res.redirect('/admin/employees');
    }
    
    const newStatus = !current.rows[0].is_active;
    await pool.query(
      'UPDATE employees SET is_active = $1 WHERE employeeid = $2',
      [newStatus, req.params.id]
    );
    
    req.flash('success_msg', `Сотрудник ${newStatus ? 'активирован' : 'деактивирован'}`);
    res.redirect('/admin/employees');
  } catch (err) {
    console.error(err);
    req.flash('error_msg', 'Ошибка при изменении статуса');
    res.redirect('/admin/employees');
  }
});

module.exports = router;